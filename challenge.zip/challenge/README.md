# Getting Started

### Steps to be added 
Before making it live we can implement one more way of notification that could be Text SMS 



